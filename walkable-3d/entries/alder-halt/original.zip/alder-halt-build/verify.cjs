const {chromium}=require('playwright');
const fs=require('fs');
const path=require('path');
const browserPath=process.env.CHROME_PATH||'C:\\Users\\jmore\\AppData\\Local\\ms-playwright\\chromium-1217\\chrome-win64\\chrome.exe';
let activeBrowser;
(async()=>{
 fs.mkdirSync('evidence',{recursive:true});
 console.log('Launching hidden test browser');
 const browser=await chromium.launch({headless:true,executablePath:browserPath,args:['--enable-webgl','--ignore-gpu-blocklist'],timeout:20000});
 activeBrowser=browser;
 console.log('Browser ready');
 const page=await browser.newPage({viewport:{width:1600,height:1000},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>{errors.push(e.message);console.log('PAGE ERROR',e.message);});page.on('console',m=>{if(m.type()==='error'){errors.push(m.text());console.log('CONSOLE ERROR',m.text());}});
 const started=Date.now();await page.goto('http://127.0.0.1:4377');console.log('Page loaded');await page.waitForFunction(()=>window.alder&&window.alder.getStats().frames>25,null,{timeout:30000});console.log('Scene ready');
 const loadMs=Date.now()-started;
 await page.screenshot({path:'evidence/01-entrance-ui.png'});
 await page.evaluate(()=>document.querySelector('#veil').classList.add('hidden'));
 const checks=await page.evaluate(()=>{
  const a=window.alder,results=[];
  a.reset();a.testMove(0,-9);results.push({name:'entrance to waiting room',...a.getPlayer()});
  a.testMove(0,-5);results.push({name:'waiting room to platform',...a.getPlayer()});
  a.testPose(-1,4.64);a.testMove(-12,0);results.push({name:'west wall collision',...a.getPlayer()});
  a.testPose(-1,2.5);a.testMove(12,0);results.push({name:'east wall collision',...a.getPlayer()});
  a.testPose(10,-1);a.testMove(0,-10);results.push({name:'crossing continuous',...a.getPlayer()});
  a.testPose(10,-10);a.testMove(6,-4);a.testMove(5,3);a.testMove(3,7);a.testMove(0,7);a.testMove(-4,5);a.testMove(-7,2);a.testMove(-7,1);a.testMove(-7,0);results.push({name:'woodland loop returns to entrance',...a.getPlayer()});
  a.reset();results.push({name:'reset',...a.getPlayer()});return results;
 });
 const views=[['02-approach',-1,11,0,-.025],['03-room',-1,3.2,Math.PI/2,-.05],['04-canopy',-1,-2.2,0,.15],['05-crossing',10,-7.5,-Math.PI/2,-.22],['06-woods',20,-11,2.1,-.05],['07-return',18,8,1.23,-.02],['08-timetable',-2.55,-1.7,Math.PI,-.07]];
 const frameTests=[];
 for(const [name,x,z,yaw,pitch] of views){await page.evaluate(v=>window.alder.testPose(...v),[x,z,yaw,pitch]);await page.waitForTimeout(1000);await page.evaluate(()=>window.alder.clearTiming());await page.waitForTimeout(2500);frameTests.push({view:name,...await page.evaluate(()=>window.alder.getStats())});await page.screenshot({path:`evidence/${name}.png`});}
 await page.evaluate(()=>{window.alder.reset();document.querySelector('#veil').classList.remove('hidden');});await page.click('#enter');await page.waitForFunction(()=>document.pointerLockElement,null,{timeout:5000});await page.waitForTimeout(700);await page.keyboard.down('w');await page.waitForTimeout(1200);await page.keyboard.up('w');const keyboardCheck=await page.evaluate(()=>window.alder.getPlayer());const beforeLook=keyboardCheck.yaw;await page.mouse.move(800,500);await page.mouse.move(970,560);await page.waitForTimeout(150);const mouseCheck=await page.evaluate(()=>window.alder.getPlayer());await page.keyboard.press('r');const resetCheck=await page.evaluate(()=>window.alder.getPlayer());await page.keyboard.press('q');await page.keyboard.press('q');const qualityCheck=await page.evaluate(()=>({value:document.querySelector('#quality').value,width:document.querySelector('canvas').width}));await page.keyboard.press('q');await page.keyboard.press('p');const perfCheck=await page.evaluate(()=>document.querySelector('#perf').style.display==='block');await page.keyboard.press('p');await page.keyboard.press('Escape');await page.waitForTimeout(600);const released=await page.evaluate(()=>!document.pointerLockElement&&!document.querySelector('#veil').classList.contains('hidden'));
 const passed={roomEntered:checks[0].z>0&&checks[0].z<5.1,platformReached:checks[1].z<0&&checks[1].z>-3.5,westWallStops:checks[2].x>-5.8,eastWallStops:checks[3].x<3.8,crossingReachedWoods:checks[4].z< -9,loopReturns:Math.hypot(checks[5].x+1,checks[5].z-11)<.15,keyboardMoves:keyboardCheck.z<11,mouseLooks:Math.abs(mouseCheck.yaw-beforeLook)>.01,resetWorks:resetCheck.x===-1&&resetCheck.z===12.7,qualityControl:qualityCheck.value==='2'&&qualityCheck.width===1360,performancePanel:perfCheck,escapeReleases:released,noRuntimeErrors:errors.length===0};
 const report={testedAt:new Date().toISOString(),browser:'headless Chromium, installed revision 1217',viewport:'1600×1000 at DPR 1',loadMs,errors,passed,checks,keyboardCheck,mouseCheck,resetCheck,qualityCheck,released,frameTests,note:'Each view warms for 1 second, then records 2.5 seconds. Screenshots are taken after the timing sample. Local headless measurements are evidence for this run only; interactive performance will be judged separately.'};
 fs.writeFileSync('evidence/verification.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();
 if(Object.values(passed).some(x=>!x))process.exitCode=1;
})().catch(async e=>{console.error(e);if(activeBrowser)await activeBrowser.close();process.exit(1);});
