import {chromium} from '@playwright/test';
import fs from 'node:fs/promises';
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',args:['--disable-background-timer-throttling','--disable-renderer-backgrounding']});
const page=await browser.newPage({viewport:{width:1440,height:900}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('http://127.0.0.1:5187/');await page.waitForFunction(()=>station.ready);await page.click('#enter');await page.waitForTimeout(500);
const lock=await page.evaluate(()=>document.pointerLockElement?.id);console.log('Pointer lock:',lock);
const results=[];await page.evaluate(()=>station.beginMeasurement());
for(const [name,x,z]of [['gate',0,-11],['entrance',0,-5.2],['waiting room',0,-1],['platform exit',0,3.7],['platform crossing approach',10,3.7],['track crossing',10,10.9],['woodland entry',10,12.7],['woodland path',14,17],['view back',20,19.5],['east loop',25,15],['east path',25,7],['east approach',21,-1],['return bend',17,-8],['return approach',10,-13],['gate return',0,-11]]){
 const start=Date.now();await page.keyboard.down('w');let distance=99,pose;
 while(Date.now()-start<15000){pose=await page.evaluate(()=>station.getPose());distance=Math.hypot(x-pose.x,z-pose.z);if(distance<.17)break;await page.evaluate(a=>station.setLook(a),Math.atan2(-(x-pose.x),-(z-pose.z)));await page.waitForTimeout(70);}
 await page.keyboard.up('w');await page.waitForTimeout(180);pose=await page.evaluate(()=>station.getPose());const result={name,target:{x,z},pose,distance:Math.hypot(x-pose.x,z-pose.z),elapsedMs:Date.now()-start};results.push(result);console.log(name,JSON.stringify(result));if(distance>.6)break;
}
const collisions=await page.evaluate(()=>({wall:!station.canMove(4.9,-2),frontWall:!station.canMove(2.5,-4.85),door:station.canMove(0,-4.85),rearDoor:station.canMove(0,1.85),post:!station.canMove(0,5.22),bench:!station.canMove(3.25,2.42),crossing:station.canMove(10,8.7),crossingFloor:station.floorHeight(10,8.7)}));
await page.keyboard.press('r');await page.waitForTimeout(200);const reset=await page.evaluate(()=>station.getPose());const stats=await page.evaluate(()=>station.metrics());await fs.writeFile('artifacts/route-frame-times.json',JSON.stringify(await page.evaluate(()=>station.frameTimes())));await page.keyboard.press('Escape');await page.waitForTimeout(200);const pause=await page.locator('#pause').isVisible();await fs.writeFile('artifacts/route-test.json',JSON.stringify({errors,pointerLock:lock,results,collisions,reset,pause,stats},null,2));console.log({errors,collisions,reset,pause,stats});await browser.close();

