import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
await fs.mkdir('artifacts',{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',args:['--disable-background-timer-throttling','--disable-renderer-backgrounding']});
const page=await browser.newPage({viewport:{width:1440,height:900},deviceScaleFactor:1});
const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.goto('http://127.0.0.1:5187/');await page.waitForFunction(()=>window.station?.ready,{timeout:60000});await page.waitForTimeout(2500);
await page.screenshot({path:'artifacts/01-entrance-ui.png'});await page.evaluate(()=>station.hideUI());
const poses=[['02-approach',7.1,-14.8,2.70,-.015],['03-waiting',0,-3.9,Math.PI,-.015],['04-platform',1,3.8,-.4,-.03],['05-crossing',10,8.7,1.35,0],['06-woodland',20,18,.77,0],['07-canopy',-4,4.4,-.8,-.2]];
for(const [name,x,z,yaw,pitch] of poses){await page.evaluate(([x,z,y,p])=>station.setPose(x,z,y,p),[x,z,yaw,pitch]);await page.waitForTimeout(700);await page.screenshot({path:`artifacts/${name}.png`});}
const info=await page.evaluate(()=>({metrics:station.metrics(),gpu:(()=>{const gl=document.querySelector('canvas').getContext('webgl2');const ext=gl.getExtension('WEBGL_debug_renderer_info');return ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):'unavailable';})()}));
await fs.writeFile('artifacts/initial-inspection.json',JSON.stringify({errors,...info},null,2));console.log(JSON.stringify({errors,...info},null,2));await browser.close();
